---
name: Feature Request
about: I have a suggestion (and might want to implement myself)
---

### Describe the feature you would like

### Suggested implementation

### Describe alternatives that you have considered
